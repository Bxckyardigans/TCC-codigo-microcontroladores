import express from "express";
import mysql from "mysql2/promise";
import fetch from "node-fetch";

const app = express();
app.use(express.json());


// CONFIGURAÇÃO DO BD

const db = await mysql.createPool({
  host: "localhost",
  user: "root",
  password: "19052008",
  database: "vacinas_db"
});


// FUNÇÃO PARA BUSCAR OS DADOS DO ESP32 RECEPTOR VIA DNS mDNS

async function receberDoESP() {
  try {
    // define o DNS do ESP32 receptor
    const url = "http://colremote.local/dados";

    const resposta = await fetch(url, { timeout: 3000 });
    const json = await resposta.json();

    console.log("📡 Dados recebidos do ESP32:", json);

    // Salva no MySQL
    await salvarNoBanco(json);

  } catch (erro) {
    console.error("❌ Erro ao receber dados do ESP32:", erro.message);
  }
}


// SALVAR NO BANCO DE DADOS

async function salvarNoBanco(dados) {
  const { temperatura, latitude, longitude, dataHora } = dados;

  await db.query(
    "INSERT INTO registros_vacinas (temperatura, latitude, longitude, dataHora) VALUES (?, ?, ?, ?)",
    [temperatura, latitude, longitude, dataHora]
  );

  console.log("💾 Dados armazenados no MySQL com sucesso!");
}


// PONTO FINAL PARA O ESP32 RECEPTOR ENVIAR DIRETAMENTE

app.post("/api/registrar", async (req, res) => {
  try {
    await salvarNoBanco(req.body);

    res.json({ status: "ok", mensagem: "Dados gravados com sucesso" });

  } catch (erro) {
    console.error(erro);
    res.status(500).json({ erro: "Falha ao salvar no banco" });
  }
});


// LOOP AUTOMÁTICO PARA BUSCAR OS DADOS DO ESP VIA DNS

// vai buscar a cada 5 segundos
setInterval(receberDoESP, 5000);


app.listen(3000, () => {
  console.log("🚀 Servidor Node rodando na porta 3000");
});
